import { Component, OnInit, ComponentFactoryResolver, ViewChild, ViewContainerRef, ViewChildren, QueryList } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent {

  @ViewChildren('vc', { read: ViewContainerRef }) _container: QueryList<ViewContainerRef>;

  public tabSelection = [
    { label: 'Profile', component: 'ProfileComponent', active: false },
    { label: 'Home', component: 'HomeComponent', active: false },
    { label: 'About', component: 'AboutComponent', active: false },
    { label: 'Devices', component: 'DevicesComponent', active: false },
  ]

  public active = '';

  public containerRef;

  public comp;

  public tabs = [];

  public load(tab) {
    this.tabSelection.forEach(t => t.active = false);
    tab.active = true;
    this.tabs.forEach(t => { t.active = false; });
    let currentTabIndex = this.tabs.findIndex(t => t.label === tab.component);
    // this.active = comp;
    const foundTab = this.tabs.find(t => t.label === tab.component);
    if (!foundTab) {
      this.tabs.push({ label: tab.component, active: true });
      currentTabIndex = this.tabs.length - 1;
      const factories = Array.from(this._resolver['_factories'].keys());
      factories.forEach((fa) => {
        if (tab.component === fa['name']) {
          setTimeout(() => {
            this.dynamicAddToViewChild(fa, currentTabIndex);
          });
        }
      });
    } else {
      this.tabs[currentTabIndex].active = true;
    }

  }

  dynamicAddToViewChild(component, index) {
    console.log(this._container, this.tabs)
    const cmpFactory = this._resolver.resolveComponentFactory(component);
    console.log(this._container['_results'])
    this._container['_results'][index].clear();
    this.containerRef = this._container['_results'][index].createComponent(cmpFactory);
  }

  constructor(private route: ActivatedRoute, private _resolver: ComponentFactoryResolver) {
    route.queryParams.subscribe(res => {
      console.log(res);
    });
  }

  remove(index) {
    this.tabs.splice(index, 1);
  }
  // ngOnInit() {
  // }

}
