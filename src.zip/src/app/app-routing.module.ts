import { ProfileComponent } from './tabs/profile/profile.component';
import { AboutComponent } from './tabs/about/about.component';
import { HomeComponent } from './tabs/home/home.component';
import { TabsComponent } from './tabs/tabs.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DevicesComponent } from './tabs/devices/devices.component';

const routes: Routes = [
  {
    path: 'tab', component: TabsComponent,
    children: [
      { path: 'home', component: HomeComponent },
      { path: 'about', component: AboutComponent },
      { path: 'devices', component: DevicesComponent },
      { path: 'profile', component: ProfileComponent }
    ],
  },
  { path: '**', redirectTo: '/tab' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
